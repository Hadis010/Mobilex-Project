/*===============================================================
// Nom du fichier : projet Mobilex
// Auteur: Dini Hafsa-Medaissi Ghada
// Date de cr�ation : F�vrier 2022
// Version : V2
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Description :
// Le syst�me mobile roulant est capable de circuler sur un circuit en �tant pilot� par un op�rateur.
// Le syst�me mobile a deux modes de fonctionnement : mode "parking manuel" et mode "parking automatique" .
// L'op�rateur peut piloter l'engin et suit le circuit en direction jusqu'� garer le robot dans la zone de parking avec des capteurs de contacts en fonction du mode choisi.
// En mode automatique , l'engin doit se garer automatiquement et sans intervention de l'op�rateur dans sa zone de parking apr�es d�t�ction du mur avec gr�ce au capteur ultrason.
//
task main()
{



}
