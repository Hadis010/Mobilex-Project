/*===============================================================
// Nom du fichier : Activite1_v1.c
// Auteur : HafsaDn
// Date de cr�ation : F�vrier 2022
// Version : V1
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Description :
											/
//-------------------------------------------------------------
// A noter :
// - le capteur de contact est sur l'entr�e 1
// - le moteur est sur la sortie A
//===============================================================*/
task main()
{
 setMotorSpeed(motorA,75);
 sleep(1000);  }
