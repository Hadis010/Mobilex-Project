
task main
{
}
	void faireTournerMobilex()
	{
	int y ;
setMotorSync(motorA,motorD,100,40);
	sleep(400);
	y = y - 10;
	displayVariableValues(10,y);
sleep(800);
}
