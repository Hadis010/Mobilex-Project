
task main(){
int mesureDistance;
mesureDistance=12;
//1) affiche le texte � gauche en haut de l'�cran
//displayText(0, "AFFICHAGE !");
//2) affiche le texte au milieu en haut de l'�cran
//splayCenteredTextLine(1, "AFFICHAGE dist!");
//3) dessine deux sph�res chacune encadr�es par un polygone
//drawBmpfile(0,127,"Black eye");
//4) affiche le texte � gauche et la mesureDistance qui est �gale � 12 sur la ligne 1
//displayTextLine(3, "AFFICHAGE dist: %d cm",mesureDistance);
//5)affiche le texte � gauche avec la valeur de mesureDistance (12) sur la ligne 14
//displayVariableValues(14,mesureDistance);
//6)les deux instructions permet d'afficher le m�me message mais sur diff�rentes lignes 4 et 5
//displayCenteredBigTextLine(4, "Dist: %d cm", mesureDistance);
//displayCenteredBigTextLine(5, "Dist: %d cm", mesureDistance);
//7) une ligne se dessine � droite de l'�cran et d'une certaine hauteur (x=150 et y= 0 � 70)
/*for(int i=0;i<70;i++){
setPixel(150,i);*/
}
