
// Nom du fichier : projet Mobilex
// Auteur: Dini Hafsa_Medaissi Ghada
// Date de cr�ation : Mars 2022
// Version : V2
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Description :
// Le syst�me mobile roulant est capable de circuler sur un circuit en �tant pilot� par un op�rateur.
// Le syst�me mobile a deux modes de fonctionnement : mode "parking manuel" et mode "parking automatique" .
// L'op�rateur peut piloter l'engin et suit le circuit en direction jusqu'� garer le robot dans la zone de parking avec des capteurs de contacts en fonction du mode choisi.
// En mode automatique , l'engin doit se garer automatiquement et sans intervention de l'op�rateur dans sa zone de parking apr�s d�t�ction du mur gr�ce au capteur ultrason.
//On peut d�marrer et arr�ter le fonctionnement du syst�me mobile soit en appuyant sur les boutons de la brique ou par un code secret .
// Le syst�me mobile peut �tre pilot� par une t�l�commande sans fil.
//Le syst�me mobile affiche sur son �cran la distance parcourue approximativement.
/*===============================================================
task main()
{



}
